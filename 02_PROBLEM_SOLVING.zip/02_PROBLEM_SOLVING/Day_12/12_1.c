//er function Template for C++

// ar[] is the array 
// n is the number of elements in array.

void print(int ar[], int n)
{
    
    int i;
    for(i=0;i<n;i+=2)
    {
        cout<<ar[i]<<" ";
    }
    
    
}