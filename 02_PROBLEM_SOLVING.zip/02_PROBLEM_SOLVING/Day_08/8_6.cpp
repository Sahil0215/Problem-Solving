#include<iostream>
using namespace std;
int main()
{
    float r,area;
    cout<<"Enter Radius: ";
    cin>>r;
    cout<<r*r;
    return 0;
}